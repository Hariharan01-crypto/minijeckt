﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class Loginpage : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string check = "Select count(*) from Register where Email_Id = '" + TextBox1.Text + "' and Password = '" + TextBox2.Text+ "' ";
        SqlCommand com = new SqlCommand(check,con);
        con.Open();
        int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
        con.Close();
        if (temp == 1)
        {
            Response.Redirect("homepage.aspx");  
        }
        else 
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Your E-Mail or Password is invalid";  
           
        }
    }
}