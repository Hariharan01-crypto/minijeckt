﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class purchase : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindDropdownList();
        }

        if (!IsPostBack)
        {
            Bind();
        }

    }

    private void Bind() {

        using (SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True"))
        {


            SqlCommand cmd = new SqlCommand("SELECT Id , brand FROM watch", conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            DropDownList1.DataTextField = "brand"; // The name to display in the dropdown
            DropDownList1.DataValueField = "Id"; // The value of each item
            DropDownList1.DataSource = reader;
            DropDownList1.DataBind();
        }
    
    
    }

  
   

    private void BindDropdownList()
        {
            using (SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True"))
            {
                
                 
                    SqlCommand cmd = new SqlCommand("SELECT cid , cname FROM customer",conn);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlItems.DataTextField = "cname"; // The name to display in the dropdown
                    ddlItems.DataValueField = "cid"; // The value of each item
                    ddlItems.DataSource = reader;
                    ddlItems.DataBind();
                }
            }
       

    protected void ddlItems_SelectedIndexChanged(object sender, EventArgs e)
    {
        int selectedId = int.Parse(ddlItems.SelectedValue);
        PopulateTextBoxes(selectedId);
    }


    protected void drop_SelectedIndexChanged(object sender, EventArgs e)
    {
        int selectedId = int.Parse(DropDownList1.SelectedValue);
        PopulateText(selectedId);
    }


    private void PopulateText(int id)
    {

        using (SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True"))
        {

            SqlCommand cmd = new SqlCommand("SELECT model, price FROM watch WHERE Id = @Id", conn);
            cmd.Parameters.AddWithValue("@Id", id);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                TextBox3.Text = reader["model"].ToString();
                TextBox6.Text = reader["price"].ToString();
            }

        }
    
    }
    private void PopulateTextBoxes(int id)
    {
        using (SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True"))
        {

            SqlCommand cmd = new SqlCommand("SELECT addrees, mobileno FROM customer WHERE cid = @cid",conn);
            cmd.Parameters.AddWithValue("@cid", id);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
               TextBox4.Text  = reader["addrees"].ToString();
               TextBox5.Text = reader["mobileno"].ToString();
            }

        }

    }


    protected void Add_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "INSERT INTO purchase VALUES('" + int.Parse(TextBox1.Text) + "','" + DropDownList1.SelectedItem + "','" + ddlItems.SelectedItem + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox6.Text + "','" + TextBox5.Text + "','" + TextBox7.Text + "')";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Inserted successfully";
        }
    }
    protected void Update_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "UPDATE purchase set brand = '" + DropDownList1.SelectedItem + "',cusname = '" + ddlItems.SelectedItem + "',model = '" + TextBox3.Text + "',address = '" + TextBox4.Text + "',price = '" + TextBox6.Text + "',mobno = '" + TextBox5.Text + "',warranty = '" + TextBox7.Text + "' where bid ='" + int.Parse(TextBox1.Text) + "' ";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Updated successfully";
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "Delete from purchase where bid = '" + TextBox1.Text + "' ";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Deleted successfully";
        }

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.RawUrl);
    }
}