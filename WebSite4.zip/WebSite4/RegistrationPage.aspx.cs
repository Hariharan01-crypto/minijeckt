﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class RegistrationPage : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)

    {
        string ins = "INSERT INTO Register VALUES('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "')";
        SqlCommand com = new SqlCommand(ins, con);
        con.Open();
        int flag= com.ExecuteNonQuery();
        con.Close();
        if (flag == 1)
        {
            Label1.Text = "Registered  successfully";
        }
    }
}