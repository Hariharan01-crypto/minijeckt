﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class employee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "INSERT INTO employee VALUES('" + int.Parse(TextBox1.Text) + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + txt6.Text + "')";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Inserted successfully";
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "UPDATE employee set empmob = '" + TextBox2.Text + "',ename = '" + TextBox3.Text + "',eaddress = '" + TextBox4.Text + "',jobtitle = '" + TextBox5.Text + "',sal = '" + txt6.Text + "' where empid ='" + int.Parse(TextBox1.Text) + "' ";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Updated successfully";
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "Delete from employee where empid = '" + TextBox1.Text + "' ";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Deleted successfully";
        }

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.RawUrl);
    }
}