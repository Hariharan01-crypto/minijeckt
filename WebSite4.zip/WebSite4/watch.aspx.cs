﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class watch : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "INSERT INTO watch VALUES('" + int.Parse(TextBox1.Text) + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Inserted successfully";
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "UPDATE watch set brand = '" + TextBox2.Text + "', model = '" + TextBox3.Text + "', price = '" + TextBox4.Text + "' where Id ='" + int.Parse(TextBox1.Text) + "' ";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Updated successfully";
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "Delete from watch where Id = '" + TextBox1.Text + "' ";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Deleted successfully";
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.RawUrl);
    }
}