﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class customer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection ("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "INSERT INTO customer VALUES('" + int.Parse(TextBox1.Text) + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')";
        cmd.Connection = con; 
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Inserted successfully";
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "UPDATE customer set addrees = '" + TextBox2.Text + "',cname = '" + TextBox3.Text + "',mobileno = '" + TextBox4.Text + "' where cid ='" + int.Parse(TextBox1.Text) + "' ";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Updated successfully";
        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\SRI GANANAYAKA\\Documents\\Visual Studio 2012\\WebSites\\WebSite4\\App_Data\\Database.mdf;Integrated Security=True");
        SqlCommand cmd = con.CreateCommand();
        con.Open();
        cmd.CommandText = "Delete from customer where cid = '"+TextBox1.Text+"' ";
        cmd.Connection = con;
        int flag = cmd.ExecuteNonQuery();
        if (flag == 1)
        {
            Label1.Text = "Deleted successfully";
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.RawUrl);
    }
}